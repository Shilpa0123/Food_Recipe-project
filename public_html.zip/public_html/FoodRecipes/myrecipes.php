<?php
// include 'db.php';
/* Database connection start */
$servername = "localhost";
$username = "shilpa";
$password = "shilpa@123";
$dbname = "foodrecipe_app";
$conn = mysqli_connect($servername, $username, $password, $dbname) or die("Connection failed: " . mysqli_connect_error());
mysqli_select_db($conn, $dbname);
$query = mysqli_query($conn, "SELECT AVG(rating),recipe_name FROM tb_fr_rating GROUP BY recipe_name");
if (mysqli_num_rows($query) > 0)
{
    while ($data = mysqli_fetch_array($query))
    {
        $result1 = mysqli_query($conn, "UPDATE tb_fr_recipes SET rating='" . $data["AVG(rating)"] . "' WHERE recipe_name ='" . $data["recipe_name"] . "';");
    }
}
if (isset($_GET["uname"]))
{
    $result2 = mysqli_query($conn, "SELECT id,recipe_name,ingredients,recipe_procedure,img_url,rating FROM tb_fr_recipes WHERE created_by='" . $_GET["uname"] . "'");
    if(mysqli_num_rows($result2) > 0){
    while ($r = mysqli_fetch_assoc($result2))
    {
        $rows[] = $r;
    }
    echo json_encode($rows);
    }
    else{
        echo json_encode(null);
        // $rows[] = array('id' => null, 'recipe_name' => null, 'ingredients' => null, 'recipe_procedure' => null, 'img_url' => null, 'rating' => null);
    }
    
}
mysqli_close($conn);

?>
