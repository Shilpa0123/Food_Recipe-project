<?php
// include 'db.php';
/* Database connection start */
$servername = "localhost";
$username = "shilpa";
$password = "shilpa@123";
$dbname = "foodrecipe_app";
$conn = mysqli_connect($servername, $username, $password, $dbname) or die("Connection failed: " . mysqli_connect_error());
mysqli_select_db($conn, $dbname);
if (isset($_GET["id"]))
{
    $result2 = mysqli_query($conn, "SELECT * FROM tb_fr_user_registration WHERE id='" . $_GET["id"] . "'");
    if (mysqli_num_rows($result2) > 0)
    {
        while ($r = mysqli_fetch_assoc($result2))
        {
            $rows[] = $r;

        }

    }
    else
    {
        $rows = null;
    }
}

echo json_encode($rows);
mysqli_close($conn);

?>
