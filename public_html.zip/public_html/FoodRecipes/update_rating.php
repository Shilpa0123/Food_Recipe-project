<?php
// include 'db.php';
/* Database connection start */
$servername = "localhost";
$username = "shilpa";
$password = "shilpa@123";
$dbname = "foodrecipe_app";
$conn = mysqli_connect($servername, $username, $password, $dbname);
mysqli_select_db($conn, $dbname);
if (isset($_GET["rating"]) || isset($_GET["recipe_name"]) || isset($_GET["uname"]))
{

    $query = "INSERT INTO tb_fr_rating (rating,uname,recipe_name) VALUES ('" . $_GET["rating"] . "','" . $_GET["uname"] . "','" . $_GET["recipe_name"] . "')";
    if (mysqli_query($conn, $query))
    {
        $response['message'] = 'Rating Updated Successfully';
        $response['status'] = true;
    }
    else
    {
        $response['message'] = 'Rating Updated Failed';
        $response['status'] = false;
    }
    echo json_encode($response);
}

mysqli_close($conn);

?>
