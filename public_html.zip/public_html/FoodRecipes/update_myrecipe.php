<?php

static $servername = "localhost";
static $dbname = "foodrecipe_app";
static $username = "shilpa";
static $password = "shilpa@123";

$con = mysqli_connect($servername, $username, $password, $dbname);
mysqli_select_db($con, $dbname);
if ($con != null)
{
    // Get image name
    

    // image file directory
    if(isset($_FILES['file'])){
        $image_name = $_FILES['file']['name'];
        $target = "images/" . basename($image_name);
        $sql = "UPDATE  tb_fr_recipes SET recipe_name = '" .trim($_POST["recipe_name"],'"')  . "',ingredients = '" . trim( $_POST["ingredients"],'"') . "',recipe_procedure = '" . trim($_POST["recipe_procedure"],'"')  . "',country_name = '" . trim($_POST["country_name"],'"') . "',img_url = '$target' WHERE id='" .  trim($_POST["id"],'"'). "'";
    }
    else
        $sql = "UPDATE  tb_fr_recipes SET recipe_name = '" . trim($_POST["recipe_name"],'"')  . "',ingredients = '" . trim( $_POST["ingredients"],'"') . "',recipe_procedure = '" . trim($_POST["recipe_procedure"],'"')  . "',country_name = '" . trim($_POST["country_name"],'"') . "' WHERE id='" .  trim($_POST["id"],'"') . "'";
    try
    {
        $result = mysqli_query($con, $sql);
        if ($result)
        {if(isset($_FILES['file'])){
            if (move_uploaded_file($_FILES['file']['tmp_name'], $target))
            {
                $update = mysqli_query($con, "INSERT INTO tb_fr_rating (rating,uname,recipe_name) VALUES (0,'" . trim( $_POST["created_by"],'"') . "','" . trim( $_POST["recipe_name"],'"') . "')");
                echo (json_encode(array(
                    "message" => "Recipe Updated Successfuly"
                )));
            }
            else
            {
                echo (json_encode(array(
                    "message" => "Saved But Unable to Move Image to Appropriate Folder"
                )));
            }
        }
        else
        echo (json_encode(array(
                    "message" => "Recipe Updated Successfuly"
                )));
        }
        else
        {
            echo (json_encode(array(
                "message" => "Recipe Upload Failed"
            )));
        }
        $con->close();
    }
    catch(Exception $e)
    {
        echo (json_encode(array(
            "message" => "Server issue, Please try again. " . $e->getMessage()
        )));
        $con->close();
    }
}
else
{
    echo (json_encode(array(
        "message" => "Database issue, Please try again."
    )));
}

// public function handleRequest() {
//     // if (isset($_POST['name'])) {
//         $this->insert();
//     // } else{
//         // $this->select();
//     // }

?>
