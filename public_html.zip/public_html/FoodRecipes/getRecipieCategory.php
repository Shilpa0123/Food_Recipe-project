<?php
// include 'db.php';
/* Database connection start */
$servername = "localhost";
$username = "shilpa";
$password = "shilpa@123";
$dbname = "foodrecipe_app";
$conn = mysqli_connect($servername, $username, $password, $dbname) or die("Connection failed: " . mysqli_connect_error());
mysqli_select_db($conn, $dbname);
$result = mysqli_query($conn, "SELECT * FROM tb_fr_category");
while ($r = mysqli_fetch_assoc($result))
{
    $rows[] = $r;
}
echo json_encode($rows);

mysqli_close($conn);

?>
