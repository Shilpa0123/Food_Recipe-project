<?php
/* Database connection start */
$servername = "localhost";
$username = "shilpa";
$password = "shilpa@123";
$dbname = "foodrecipe_app";
$conn = mysqli_connect($servername, $username, $password, $dbname);

/* check connection */
if (mysqli_connect_errno())
{
    $response['error'] = false;
    $response['message'] = 'Invalid Operation Called';
    exit();
}
else
{
    $response['error'] = true;
    $response['message'] = 'Database Connected';
}
echo json_encode($response);
?>
