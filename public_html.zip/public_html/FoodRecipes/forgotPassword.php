<?php
// include 'db.php';
/* Database connection start */
$servername = "localhost";
$username = "shilpa";
$password = "shilpa@123";
$dbname = "foodrecipe_app";
$conn = mysqli_connect($servername, $username, $password, $dbname) or die("Connection failed: " . mysqli_connect_error());
mysqli_select_db($conn, $dbname);
if (isset($_GET["emailid"]))
{
    $result = mysqli_query($conn, "SELECT * FROM tb_fr_user_registration WHERE emailid='".$_GET["emailid"]."'");
    if (mysqli_num_rows($result) > 0)
    {
        $id = mysqli_fetch_array(mysqli_query($conn, "SELECT pwd FROM tb_fr_user_registration WHERE emailid='".$_GET["emailid"]."'"));
        $response['message'] = "Your password is'".$id['pwd']."'";
        $response['status'] = true;
        $response['id'] = true;

    }
    else
    {
        $response['message'] = 'User Not Found';
        $response['status'] = false;
        $response['id'] = false;
    }
    echo json_encode($response);
}

mysqli_close($conn);

?>
