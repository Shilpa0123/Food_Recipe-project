<?php

static $servername = "localhost";
static $dbname = "foodrecipe_app";
static $username = "shilpa";
static $password = "shilpa@123";

$con = mysqli_connect($servername, $username, $password, $dbname);
mysqli_select_db($con, $dbname);
if ($con != null)
{
    // Get image name
    $image_name = $_FILES['file']['name'];

    // image file directory
    $target = "images/" . basename($image_name);
    $sql = "INSERT INTO tb_fr_recipes (recipe_name,ingredients,recipe_procedure,country_name,created_by,img_url) VALUES ('" . trim($_POST["recipe_name"],'"') . "','" .trim( $_POST["ingredients"],'"') . "','" . trim($_POST["recipe_procedure"],'"') . "','" . trim($_POST["country_name"],'"'). "','" . trim($_POST["created_by"],'"') . "','$target')";
    try
    {
        $result = mysqli_query($con, $sql);
        if ($result)
        {
            if (move_uploaded_file($_FILES['file']['tmp_name'], $target))
            {
                $update = mysqli_query($con, "INSERT INTO tb_fr_rating (rating,uname,recipe_name) VALUES (0,'" . trim($_POST["created_by"],'"') . "','" . trim($_POST["recipe_name"],'"') . "')");
                echo (json_encode(array(
                    "message" => "Recipe Uploaded Successfuly"
                )));
            }
            else
            {
                echo (json_encode(array(
                    "message" => "Saved But Unable to Move Image to Appropriate Folder"
                )));
            }
        }
        else
        {
            echo (json_encode(array(
                "message" => "Recipe Upload Failed"
            )));
        }
        $con->close();
    }
    catch(Exception $e)
    {
        echo (json_encode(array(
            "message" => "Server issue, Please try again. " . $e->getMessage()
        )));
        $con->close();
    }
}
else
{
    echo (json_encode(array(
        "message" => "Database issue, Please try again."
    )));
}

// public function handleRequest() {
//     // if (isset($_POST['name'])) {
//         $this->insert();
//     // } else{
//         // $this->select();
//     // }

?>
