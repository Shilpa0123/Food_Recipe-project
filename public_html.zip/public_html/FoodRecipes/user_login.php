<?php
// include 'db.php';
/* Database connection start */
$servername = "localhost";
$username = "shilpa";
$password = "shilpa@123";
$dbname = "foodrecipe_app";
$conn = mysqli_connect($servername, $username, $password, $dbname) or die("Connection failed: " . mysqli_connect_error());
mysqli_select_db($conn, $dbname);
if (isset($_GET["uname"]) || isset($_GET["pwd"]))
{
    $result = mysqli_query($conn, "SELECT * FROM tb_fr_user_registration WHERE uname='" . $_GET["uname"] . "' AND  pwd = '" . $_GET["pwd"] . "'");
    if (mysqli_num_rows($result) > 0)
    {
        $id = mysqli_fetch_array(mysqli_query($conn, "SELECT id FROM tb_fr_user_registration WHERE uname='" . $_GET["uname"] . "'"));
        $response['message'] = 'Login Successful';
        $response['status'] = true;
        $response['id'] = $id['id'];

    }
    else
    {
        $response['message'] = 'Login Failed';
        $response['status'] = false;
        $response['id'] = false;
    }
    echo json_encode($response);
}

mysqli_close($conn);

?>
