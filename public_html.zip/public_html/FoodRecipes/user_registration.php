<?php
// include 'db.php';
/* Database connection start */
$servername = "localhost";
$username = "shilpa";
$password = "shilpa@123";
$dbname = "foodrecipe_app";
$conn = mysqli_connect($servername, $username, $password, $dbname);
mysqli_select_db($conn, $dbname);
if (isset($_GET["name"]) || isset($_GET["phone"]) || isset($_GET["emailid"]) || isset($_GET["uname1"]) || isset($_GET["pwd1"]))
{
    $result=mysqli_query($conn, "INSERT INTO tb_fr_user_registration (name,phone,emailid,uname,pwd)
    VALUES ('" . $_GET["name"] . "','" . $_GET["phone"] . "','" . $_GET["emailid"] . "','" . $_GET["uname1"] . "','" . $_GET["pwd1"] . "')");
    if ($result)
    {
        $id = mysqli_fetch_array(mysqli_query($conn, "SELECT id FROM tb_fr_user_registration WHERE uname='" . $_GET["uname1"] . "'"));
        $response['message'] = 'User Registration Successful';
        $response['status'] = true;
        $response['id'] = $id['id'];
    }
    else
    {   $response['message'] = 'Signup Failed';
        $response['status'] = false;
        $response['id'] = false;
    }
    echo json_encode($response);
}

mysqli_close($conn);

?>
