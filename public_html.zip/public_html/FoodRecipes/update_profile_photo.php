<?php

static $servername = "localhost";
static $dbname = "foodrecipe_app";
static $username = "shilpa";
static $password = "shilpa@123";

$con = mysqli_connect($servername, $username, $password, $dbname);
mysqli_select_db($con, $dbname);
if ($con != null)
{
    // Get image name
    $image_name = $_FILES['file']['name'];

    // image file directory
    $target = "profile/" . basename($image_name);
    $sql = "UPDATE tb_fr_user_registration SET profile_photo='" . $target. "' WHERE id='" . $_GET["id"] . "'";
    try
    {

        if (mysqli_query($con, $sql))
        {
            if (move_uploaded_file($_FILES['file']['tmp_name'], $target))
            {
                $response['message'] = 'Profile Photo Updated Successfully';
                $response['status'] = true;
            }
            else
            {
                $response['message'] = 'Failed To Save';
                $response['status'] = false;
            }
        }
        else
        {
            $response['message'] = 'Profile Photo Update Failed';
            $response['status'] = false;
        }
        $con->close();
    }
    catch(Exception $e)
    {
        $response['message'] = 'Server Error';
            $response['status'] = false;
        $con->close();
    }
}
else
{
    $response['message'] = 'Database Error';
            $response['status'] = false;
}
echo json_encode($response);
// public function handleRequest() {
//     // if (isset($_POST['name'])) {
//         $this->insert();
//     // } else{
//         // $this->select();
//     // }

?>
