<?php
// include 'db.php';
/* Database connection start */
$servername = "localhost";
$username = "shilpa";
$password = "shilpa@123";
$dbname = "foodrecipe_app";
$conn = mysqli_connect($servername, $username, $password, $dbname);
mysqli_select_db($conn, $dbname);
if (isset($_GET["name"]) || isset($_GET["phone"]) || isset($_GET["emailid"]) || isset($_GET["uname1"]) || isset($_GET["pwd1"]))
{

    $query = "UPDATE tb_fr_user_registration SET name='" . $_GET["name"] . "',phone='" . $_GET["phone"] . "',emailid='" . $_GET["emailid"] . "',uname='" . $_GET["uname1"] . "',pwd='" . $_GET["pwd1"] . "' WHERE id='" . $_GET["id"] . "'";
    if (mysqli_query($conn, $query))
    {
        $response['message'] = 'User Details Updated Successfully';
        $response['status'] = true;
    }
    else
    {
        $response['message'] = 'User Detail Update Failed';
        $response['status'] = false;
    }
    echo json_encode($response);
}

mysqli_close($conn);

?>
